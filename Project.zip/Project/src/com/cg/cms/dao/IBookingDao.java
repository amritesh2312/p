package com.cg.cms.dao;

import java.util.List;

import com.cg.cms.dto.Booking;
import com.cg.cms.dto.Flight;
import com.cg.cms.dto.User;
import com.cg.cms.exception.BookingException;

public interface IBookingDao {
	public Booking addBooking(Booking booking) throws BookingException;
	public Booking updateBooking(int id, int passengers, String classType, int fare, int seats, 
			String creditCard, String srcCity, String deptCity) throws BookingException;
	public List<Booking> getBookingList() throws BookingException;
	public Booking deleteBooking(int id) throws BookingException;
	public List<Flight> getFlightList() throws BookingException;
}
