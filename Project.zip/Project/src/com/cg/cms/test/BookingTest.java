package com.cg.cms.test;



import org.junit.Test;

import junit.framework.Assert;

import com.cg.cms.dao.BookingDaoImpl;
import com.cg.cms.dao.IBookingDao;
import com.cg.cms.dto.Booking;

import com.cg.cms.exception.BookingException;

public class BookingTest {

	@Test
	public void testInsert(){
		Booking s1= new Booking();
		s1.setBookingId(1);
		s1.setCustEmail("cap@capgemini.com");
		s1.setPassengers(3);
		s1.setClassType("Business");
		s1.setTotalFare(10000);
		s1.setSeatNo(6);
		s1.setCreditInfo("1234567890");
		s1.setSrcCity("Pune");
		s1.setDestCity("Kolkata");
		
		IBookingDao dao= new BookingDaoImpl();
		try {
			Booking s=dao.addBooking(s1);
			Assert.assertNotSame(0,s.getBookingId());
		} catch (BookingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}	
	@Test(expected=BookingException.class)
	public void testInsertForInvalidCourseCode() throws BookingException{
		Booking s1= new Booking();
		s1.setBookingId(1);
		s1.setCustEmail("cap@capgemini.com");
		s1.setPassengers(100);
		s1.setClassType("Business");
		s1.setTotalFare(100);
		s1.setSeatNo(6);
		s1.setCreditInfo("12345678908");
		s1.setSrcCity("Pune");
		s1.setDestCity("Kolkata");
		IBookingDao dao= new BookingDaoImpl();
		Booking s=dao.addBooking(s1);
	}
	
}
