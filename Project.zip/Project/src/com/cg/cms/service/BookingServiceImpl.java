package com.cg.cms.service;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.cms.dao.BookingDaoImpl;
import com.cg.cms.dao.IBookingDao;
import com.cg.cms.dto.Booking;
import com.cg.cms.dto.Flight;
import com.cg.cms.dto.User;
import com.cg.cms.exception.BookingException;

public class BookingServiceImpl implements IBookingService{

	IBookingDao dao;
	public BookingServiceImpl(){
		dao= new BookingDaoImpl();
	}
	@Override
	public Booking addBooking(Booking booking) throws BookingException {
		return dao.addBooking(booking);
	}

	@Override
	public Booking updateBooking(int id, int passengers, String classType, int fare, int seats, 
			String creditCard, String srcCity, String deptCity) throws BookingException {
		return dao.updateBooking(id, passengers, classType, fare, seats, creditCard, srcCity, deptCity);
	}

	@Override
	public List<Booking> getBookingList() throws BookingException {
		return dao.getBookingList();
	}
	
	@Override
	public Booking deleteBooking(int id) throws BookingException {
		return dao.deleteBooking(id);
	}
	
	
	@Override
	public List<Flight> getFlightList() throws BookingException {
		return dao.getFlightList();
	}
	
	
	@Override
	public boolean validateDetails(Booking booking) throws BookingException {
		
		Pattern pattern=Pattern.compile("[a-zA-Z0-9]*@[a-zA-Z0-9].com");
		Matcher matcher= pattern.matcher(booking.getCustEmail());
		if(matcher.matches()){
			pattern= Pattern.compile("[0-9]{10}");
			matcher= pattern.matcher(booking.getCreditInfo());
			if(matcher.matches())
				return true;
			else 
				throw new BookingException("Invalid Credit Card no ");
		}
		else
			throw new BookingException("Invalid Mail Id");
		
		
		
	}
	
	

	}
	


